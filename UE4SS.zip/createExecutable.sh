if ! [ -e ./PalServer ]; then
    sudo apt-get install --reinstall build-essential
    make PalServer
    rm createExecutable.sh PalServer.sh
fi